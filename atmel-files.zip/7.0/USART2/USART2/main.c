/*
 * USART2.c
 *
 * Created: 3/9/2016 8:02:36 PM
 * Author : Jeet
 */ 

#include <avr/io.h>
#include "C:\includes\usart.h"
enum SM_States5 {Start5, Rec_USART1, Rec_USART2, Rec_USART3} SM_State5;
	unsigned char seg7=0x00;
void SM_Tick5()
{
	switch (SM_State5)
	{
		case Start5:
		initUSART(0);
		USART_Flush(0);
		SM_State5=Rec_USART1;
		break;
		
		case Rec_USART1:
		if(USART_HasReceived(0)!=0)
		{
			SM_State5=Rec_USART2;
			seg7=USART_Receive(0);
		}
		else
		SM_State5=Rec_USART1;
		break;
		
		case Rec_USART2:
		USART_Flush(0);
		SM_State5=Rec_USART1;
		break;
		
		default:break;
	}
}

int main(void)
{
    /* Replace with your application code */
	DDRD=0x00;PORTD=0xFF;
	DDRB=0xFF; PORTB=0x00;
	SM_State5=Start5;
    while (1) 
    {
		SM_Tick5();
		PORTB=seg7;
    }
}

