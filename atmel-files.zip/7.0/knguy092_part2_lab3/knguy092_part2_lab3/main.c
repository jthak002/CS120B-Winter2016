/*
 * knguy092_lab2_part3.c
 *
 * Created: 1/15/2016 3:17:52 AM
 * Author : Darth Kevin
 */ 

#include <avr/io.h>

enum States{start, iterate, doNothing} state;
unsigned char button = 0;
unsigned char counter = 0;

void Tick(){
	button = (~PINA) & 0x01;  //checks the zero bit
	
	default:
		state = start;
		break;
		
	case iterate:
		if (button == 0x01){
			state = iterate;
		}
		else 
		{
			state = doNothing;
		}
		break;
		
	case doNothing:
		if (button == 0x01){
			if (counter < 6){
				state = increment;
				counter++;
			}
			else if (counter == 6){
				state = doNothing;
				counter = 0;
			}
		}
		else{
			state = doNothing;
		}
		break;
		
		PINB = counter;
}

int main(void)
{
    /* Replace with your application code */
	DDRB = 0xFF;
	PORTB = 0x00;
	DDRA = 0x00;
	PORTA = 0xFF;
	
	state = start;
    while (1) 
    {
		Tick();
    }


