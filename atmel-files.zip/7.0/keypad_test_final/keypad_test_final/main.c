/*
 * keypad_test_final.c
 *
 * Created: 3/8/2016 1:07:50 PM
 * Author : Jeet
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>
#include "C:\includes\keypad.h"
#include "C:\includes\io.c"

//**********TIMER_CODE********************
volatile unsigned char TimerFlag = 0;
unsigned long avr_timer_M = 1;
unsigned long avr_timer_cntcurr = 0;
void TimerISR(){TimerFlag=1;}
void TimerOn(){
	TCCR1B = 0x0B;
	OCR1A = 125;
	TIMSK1 = 0x02;
	TCNT1 = 0;
	avr_timer_cntcurr = avr_timer_M;
	SREG = 0x80;
}

void TimerOff(){
	TCCR1B = 0x00;
}


ISR(TIMER1_COMPA_vect){
	avr_timer_cntcurr--;
	if (avr_timer_cntcurr == 0){
		TimerISR();
		avr_timer_cntcurr = avr_timer_M;
		
	}
}

void TimerSet(unsigned long M){
	avr_timer_M = M;
	avr_timer_cntcurr = avr_timer_M;
	
}
//**********END_OF_TIMER_CODE************


int main(void)
{
    DDRA=0xFF;PORTA=0x00;
	DDRC = 0xF0;
	PORTC = 0x0F;
	DDRD=0xFF;PORTD=0x00;
	TimerOn();
	TimerSet(200);
	LCD_init();
    while (1) 
    {
		unsigned char a=GetKeypadKey();
		LCD_Cursor(1);
		switch (a) {
			// All 5 LEDs on
			case '\0':  break;
			// hex equivalent
			case '1': LCD_WriteData(a); break;
			case '2': LCD_WriteData(a); break;
			case '3': LCD_WriteData(a); break;
			case '4': LCD_WriteData(a); break;
			case '5': LCD_WriteData(a); break;
			case '6': LCD_WriteData(a); break;
			case '7': LCD_WriteData(a); break;
			case '8': LCD_WriteData(a); break;
			case '9': LCD_WriteData(a); break;
			// . . . ***** FINISH *****
			case 'A': LCD_WriteData(a); break;
			case 'B': LCD_WriteData(a); break;
			case 'C': LCD_WriteData(a); break;
			case 'D': LCD_WriteData(a); break;
			case '*': LCD_WriteData(a); break;
			case '0': LCD_WriteData(a); break;
			case '#': LCD_WriteData(a); break;
			// Should never occur. Middle LED off.
			default: LCD_WriteData(' '); break;
			
		}
		while(!TimerFlag){}
		TimerFlag=0;
    }
}

