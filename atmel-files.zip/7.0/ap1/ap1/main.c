/*
 * ap1.c
 *
 * Created: 3/13/2016 10:21:06 PM
 * Author : Jeet
 */ 

#include <avr32/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

