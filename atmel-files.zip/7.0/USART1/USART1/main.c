/*
 * USART1.c
 *
 * Created: 3/9/2016 7:58:57 PM
 * Author : Jeet
 */ 

#include <avr/io.h>
#include "C:\includes\usart.h"
enum SM_states5 {Start5, SendUSART1, SendUSART2, SendUSART3} SM_state5;
void SM_Tick5()
{
	switch(SM_state5)
	{
		case Start5:
		SM_state5=SendUSART1;
		initUSART(0);
		USART_Flush(0);
		break;
		
		case SendUSART1:
		if(USART_IsSendReady(0)!=0)
		SM_state5=SendUSART2;
		else
		SM_state5=SendUSART1;
		break;
		
		case SendUSART2:
		USART_Send(0x07,0);
		SM_state5=SendUSART3;
		break;
		
		case SendUSART3:
		if(USART_HasTransmitted(0)!=0)
		{
			USART_Flush(0);
			SM_state5=SendUSART1;
		}
		else
		{
			SM_state5=SendUSART3;
		}
		break;
		default:break;
	}

}
int main(void)
{
    /* Replace with your application code */
	DDRD=0xFF;PORTD=0x00;
	SM_state5=Start5;
    while (1) 
    {
		SM_Tick5();
    }
}

