/*
 * jthak002_lab6_part2.c
 *
 * Created: 2/14/2016 10:30:32 AM
 * Author : Jeet
 */ 
/*
 * jthak002_lab6_part1.c
 *
 * Created: 2/14/2016 9:40:02 AM
 * Author : Jeet
 */ 

#include <avr/io.h>

void ADC_init() {
	ADCSRA |= (1 << ADEN) | (1 << ADSC) | (1 << ADATE);
	// ADEN: setting this bit enables analog-to-digital conversion.
	// ADSC: setting this bit starts the first conversion.
	// ADATE: setting this bit enables auto-triggering. Since we are
	// in Free Running Mode, a new conversion will trigger
	// whenever the previous conversion completes.
}



int main(void)
{
	DDRB=0xFF; PORTB=0x00;
	DDRD=0xFF; PORTD=0x00;
    unsigned char valB=0x00;
    unsigned char valD=0x00;
	unsigned short max=0x00;
	ADC_init();
	while (1) 
    {
		
		unsigned short x = ADC; // Value of ADC register now stored in variable x.
		valB=(char)x;
		valD=(char)(x>>8);
		if(max<x)
			max=x;
		PORTB=valB;
		PORTD=valD;
    }
}

