/*
 * lab_chip.c
 *
 * Created: 1/14/2016 11:55:15 AM
 * Author : Jeet
 */ 

#include <avr/io.h>
int main(void)
{
	// Configure port B's 8 pins as outputs
	DDRB = 0xFF; PORTB = 0x00;
	while(1)
	{
		// Write to port B's 8 pins with 00001111
		PORTB = 0x0F;
	}
}

